
 export const user =[
    {
        
        name: "Mayur Burange",
        cert_no: "7507367559",
        date:"15/03/2024"
    }
]