import React from 'react'
// import 'bootstrap/dist/css/bootstrap.min.css';
import Certificate from './components/certificate.js'
// import { BrowserRouter,Routes,Route } from 'react-router-dom'
// import Login from './components/login';


const App = () => {
  return (
    <div>
       {/* <LoginForm/> */}
       <Certificate/>
    </div>
  )
}

export default App
