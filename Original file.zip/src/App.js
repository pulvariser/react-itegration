import React from 'react'
// import 'bootstrap/dist/css/bootstrap.min.css';
import Certificate from './components/certificate.js'
// import LoginForm from './components/login';

const App = () => {
  return (
    <div>
       <Certificate/>
       {/* <LoginForm/> */}
       
    </div>
  )
}

export default App
