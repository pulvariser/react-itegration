import React, { useState } from 'react';
import { Form, Button } from 'react-bootstrap';

const LoginForm = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Prepare user data
    const userData = {
      username: username,
      password: password
    };

    try {
      // Send POST request to backend
      const response = await fetch('/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(userData)
      });

      if (response.ok) {
        // Retrieve JWT token from response
        const data = await response.json();
        const token = data.token;

        // Store JWT token in localStorage or sessionStorage
        localStorage.setItem('token', token);

        // Redirect or perform any other actions
        console.log('Login successful');
      } else {
        // Handle login failure
        setError('Invalid username or password');
      }
    } catch (error) {
      console.error('Error:', error);
      setError('An error occurred while logging in');
    }
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group controlId="formBasicEmail">
        <Form.Label>Username:</Form.Label>
        <Form.Control
          type="text"
          placeholder="Enter username"
          value={username}
          onChange={handleUsernameChange}
        />
      </Form.Group>

      <Form.Group controlId="formBasicPassword">
        <Form.Label>Password:</Form.Label>
        <Form.Control
          type="password"
          placeholder="Password"
          value={password}
          onChange={handlePasswordChange}
        />
      </Form.Group>

      {error && <div className="text-danger">{error}</div>}

      <Button variant="primary" type="submit">
        Submit
      </Button>
    </Form>
  );
};

export default LoginForm;























// import React from 'react'

// const Login = () => {
//   return (
//     <div className='loginForm'>
//           <form action=''>
//              <label for="userName">Fullname:</label>
//              <input type='text' placeholder='Enter your Name' name='name' id='userName'/>

//              <label for="email">Email:</label>
//              <input type='email' placeholder='Enter your Email' name='name' id='email'/>\

//              <label for="password">password</label>
//              <input type='text' placeholder='Enter your Password' name='name' id='password'/>

//              <input type='submit' value="Submit"/>
//              <input type='reset' value='Reset'/>
//           </form>
//     </div>
//   )
// }

// export default Login;
